#include "blas3pp.h"

/** @file blas3++.h
 * @brief Deprecated; use blas3pp.h instead
 */
