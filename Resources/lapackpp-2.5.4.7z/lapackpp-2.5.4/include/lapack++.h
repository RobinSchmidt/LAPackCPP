#include "lapackpp.h"

/** @file lapack++.h
 * @brief Deprecated; use lapackpp.h instead
 */
