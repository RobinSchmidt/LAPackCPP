#include "blas2pp.h"

/** @file blas2++.h
 * @brief Deprecated; use blas2pp.h instead
 */
